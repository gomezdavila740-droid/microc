#include <stdio.h>
#include <string.h>
#include "esp_log.h"
#include "cJSON.h"


static const char *TAG = "JSON_PARSER";

void procesar_trama_json(const char *json_raw) {
    // Intentar parsear el objeto JSON
    cJSON *root = cJSON_Parse(json_raw);
    if (root == NULL) {
        printf("Error: Formato JSON invalido.\n");
        return;
    }

    // 1. Obtener punteros a las claves (Independencia del orden)
    cJSON *id = cJSON_GetObjectItem(root, "ID");
    cJSON *temp = cJSON_GetObjectItem(root, "Temperatura");
    cJSON *hum = cJSON_GetObjectItem(root, "Humedad");
    cJSON *dist = cJSON_GetObjectItem(root, "Distancia");

    // 2. Validación de Integridad: ¿Existen todas las claves obligatorias?
    if (id == NULL || temp == NULL || hum == NULL || dist == NULL) {
        printf("Error: Faltan claves obligatorias en el JSON.\n");
        cJSON_Delete(root);
        return;
    }

    // 3. Validación de Tipo: ¿Los datos corresponden a lo especificado?
    // ID -> string, los demás -> numéricos
    if (!cJSON_IsString(id) || !cJSON_IsNumber(temp) || 
        !cJSON_IsNumber(hum) || !cJSON_IsNumber(dist)) {
        // Si el tipo es incorrecto, el mensaje se ignora por completo
        cJSON_Delete(root);
        return; 
    }

    // 4. Extracción y Salida (Manejo de claves excedentes es automático con cJSON_GetObjectItem)
    printf("--- Datos Recibidos ---\n");
    printf("ID: %s\n", id->valuestring);
    printf("Temperatura: %.2f\n", temp->valuedouble);
    printf("Humedad: %.2f\n", hum->valuedouble);
    printf("Distancia: %.2f\n", dist->valuedouble);
    printf("-----------------------\n");

    // Liberar memoria
    cJSON_Delete(root);
}

void app_main(void) {
    // Ejemplo de trama correcta
    const char *trama_valida = "{\"Temperatura\": 25.5, \"ID\": \"ESP32_01\", \"Distancia\": 10.2, \"Humedad\": 60, \"Extra\": 99}";
    
    // Ejemplo con error de tipo (Humedad como string)
    const char *trama_error_tipo = "{\"ID\": \"ESP32_01\", \"Temperatura\": 22.0, \"Humedad\": \"60\", \"Distancia\": 5.0}";

    printf("Probando trama valida:\n");
    procesar_trama_json(trama_valida);

    printf("\nProbando trama con error de tipo (debe ser ignorada):\n");
    procesar_trama_json(trama_error_tipo);
}
